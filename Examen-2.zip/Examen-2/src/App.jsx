import React, { useState } from 'react';
import './index.css';

const CotizacionForm = () => {
    const [nombre, setNombre] = useState('');
    const [correo, setCorreo] = useState('');
    const [cantidad, setCantidad] = useState('');
    const [tipoEntrega, setTipoEntrega] = useState('');
    const [acepto, setAcepto] = useState(false);

    const handleCantidadChange = (e) => {
        const value = e.target.value;
        if (value === '' || (Number(value) >= 0 && !isNaN(value))) {
            setCantidad(value);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        alert('Cotización enviada');
    };

    return (
        <div className="cotizacion-form-container">
            <h2>Joan Francisco López De La Cruz 5-O Cotizar producto</h2>
            <p>Obtén tu cotización personalizada en segundos.</p>
            <form onSubmit={handleSubmit}>
                <section>
                    <h3>Información de contacto</h3>
                    <div className="form-row">
                        <div>
                            <label>Nombre</label>
                            <input type="text" value={nombre} onChange={(e) => setNombre(e.target.value)} />
                        </div>
                        <div>
                            <label>Correo</label>
                            <input type="email" value={correo} onChange={(e) => setCorreo(e.target.value)} />
                        </div>
                    </div>
                </section>
                <section>
                    <h3>Información adicional</h3>
                    <div className="form-row">
                        <div>
                            <label>Cantidad de productos</label>
                            <input
                                type="number"
                                value={cantidad}
                                onChange={handleCantidadChange}
                                min="0"
                            />
                        </div>
                        <div>
                            <label>Tipo de entrega</label>
                            <select value={tipoEntrega} onChange={(e) => setTipoEntrega(e.target.value)}>
                                <option value="">Seleccionar</option>
                                <option value="Rapida">Rapida</option>
                                <option value="normal">Normal</option>
                            </select>
                        </div>
                    </div>
                </section>
                <div>
                    <input
                        type="checkbox"
                        checked={acepto}
                        onChange={(e) => setAcepto(e.target.checked)}
                    />
                    <label>Acepto los términos y condiciones</label>
                </div>
                <button type="submit">Enviar cotización</button>
            </form>
        </div>
    );
};

export default CotizacionForm;
